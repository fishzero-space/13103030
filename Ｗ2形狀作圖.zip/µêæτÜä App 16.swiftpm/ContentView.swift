import SwiftUI

struct ContentView : View {
    var body: some View {
        ZStack(alignment:.center)
        { 
            Rectangle()
                .foregroundStyle(Gradient(colors:[.black,.blue,])
            )
                .ignoresSafeArea()
            Text(
                  """
                   Too
                   dark...
                  """
            )
            .font(.largeTitle)
            .foregroundStyle(.white)
            .shadow(radius: 30)
            .offset(x:-100, y:-195)
            
            Rectangle()
                .frame(width: 50, height: 90)
                .foregroundStyle(Color.white)
                .rotationEffect(.degrees(10))
                .offset(x: -22,y: 315)
            Circle() 
                .trim(from: 0.5, to: 1)
                .frame(width: 80, height:80)
                .foregroundStyle(.white)
                .rotationEffect(.degrees(20))
                .offset(x: -10, y: 368) //right foot
            Rectangle()
                .frame(width: 50, height: 115)
                .foregroundStyle(Color.white)
                .offset(x: 70,y: 310)
            Circle() 
                .trim(from: 0.5, to: 1)
                .frame(width: 80, height: 80)
                .foregroundStyle(.white)
                .rotationEffect(.degrees(8))
                .offset(x: 90, y: 370) //left foot
            
            Circle() 
                .trim(from: 0.5, to: 1)
                .frame(width: 170, height: 160)
                .foregroundStyle(.white)
                .rotationEffect(.degrees(70))
                .offset(x: 70, y: 100) 
            Ellipse()
                .frame(width: 70, height: 220)
                .foregroundStyle(Color.black)
                .offset(x: 80,y:5) //脖子陰影
            
            Ellipse()
                .frame(width: 220, height: 280)
                .foregroundStyle(Color.white)
                .offset(x: 20,y: 130) //body
            Ellipse()
                .frame(width: 220, height: 300)
                .foregroundStyle(Color.white)
                .offset(x: 0,y: 160) //body      
            Ellipse()
                .frame(width: 70, height: 200)
                .foregroundStyle(Color.white)
                .offset(x: 75,y: 0)
            RoundedRectangle(cornerRadius: 20)
                .frame(width:20.0, height: 180.0)
                .foregroundStyle(.white)
                .offset(x:85, y:5)//脖子
            Circle() 
                .trim(from: 0.2, to: 0.3)
                .frame(width: 240, height: 240)
                .foregroundStyle(Color.black)
                .offset(x: 30, y: 192) //body shadow
            Circle() 
                .frame(width: 240, height: 240)
                .foregroundStyle(Color.white)
                .offset(x: 30, y: 190) //body
            
            Circle()
                .trim(from: 0, to: 0.2)
                .frame(width: 180, height:180)
                .foregroundStyle(Color.white)
                .offset(x:-123, y: -145)//face
            Circle()
                .trim(from: 0.55, to: 0.8)
                .frame(width: 210, height:210)
                .foregroundStyle(Color.white)
                .offset(x:-30, y: 10)
            Circle()
                .trim(from: 0.5, to: 0.7)
                .frame(width: 120, height:120)
                .foregroundStyle(Color.white)
                .offset(x:20, y: -120)
            Ellipse()
                .frame(width: 25, height: 180)
                .foregroundStyle(Color.white)
                .offset(x: -5,y: -120)//右耳朵
            Ellipse()
                .frame(width:40, height: 190)
                .foregroundStyle(Color.white)
                .offset(x: 75,y: -115)//左耳朵
            UnevenRoundedRectangle(topLeadingRadius: 25, bottomLeadingRadius: 10, bottomTrailingRadius: 35, topTrailingRadius: 55)
                .frame(width: 120, height: 120.0)
                .foregroundStyle(.white)
                .offset(x: 35,y: -110)
            Ellipse()
                .frame(width: 160, height: 220)
                .foregroundStyle(Color.white)
                .offset(x: 15,y: -60)//頭
            
            
            Ellipse()
                .frame(width: 160, height: 120)
                .foregroundStyle(Color.black)
                .offset(x: -20,y: 8)//下巴陰影
            Ellipse()
                .frame(width: 200, height: 150)
                .foregroundStyle(Color.white)
                .offset(x: -32,y: -8)//下巴
            Ellipse()
                .frame(width: 50, height: 35)
                .foregroundStyle(Color.black)
                .rotationEffect(.degrees(125))
                .offset(x: 5,y: -75)
            Ellipse()
                .frame(width: 45, height: 30)
                .foregroundStyle(Color.white)
                .rotationEffect(.degrees(125))
                .offset(x: 5,y: -75) 
            Ellipse()
                .frame(width: 20, height:25)
                .foregroundStyle(Color.black)
                .rotationEffect(.degrees(30))
                .offset(x:4, y: -82) //right eye
            
            Ellipse()
                .frame(width: 42, height: 27)
                .foregroundStyle(Color.black)
                .rotationEffect(.degrees(120))
                .offset(x: -60,y: -85)
            Ellipse()
                .frame(width: 37, height: 22)
                .foregroundStyle(Color.white)
                .rotationEffect(.degrees(120))
                .offset(x: -60,y: -85)
            Ellipse()
                .frame(width: 15, height:20)
                .foregroundStyle(Color.black)
                .rotationEffect(.degrees(30))
                .offset(x:-60, y: -92) //left eye
            
            Circle()
                .trim(from: 0.55, to: 0.8)
                .frame(width: 160, height:160)
                .foregroundStyle(Color.white)
                .rotationEffect(.degrees(-2))
                .offset(x:-80, y: 320)
            Circle()
                .trim(from: 0.25, to: 0.50)
                .frame(width: 160, height:160)
                .foregroundStyle(Color.white)
                .rotationEffect(.degrees(80))
                .offset(x:-80, y: 320)
            Circle()
                .trim(from: 0.20, to: 0.53)
                .frame(width: 155, height:125)
                .foregroundStyle(Color.white)
                .rotationEffect(.degrees(20))
                .offset(x:-98, y: 315)
            Ellipse()
                .frame(width: 50, height: 20)
                .foregroundStyle(Color.white)
                .rotationEffect(.degrees(-20))
                .offset(x: -80,y: 360)
            Ellipse()
                .frame(width: 60, height: 20)
                .foregroundStyle(Color.white)
                .rotationEffect(.degrees(5))
                .offset(x: -85,y: 370)
            Ellipse()
                .frame(width: 60, height: 15)
                .foregroundStyle(Color.white)
                .rotationEffect(.degrees(25))
                .offset(x: -85,y: 375)
            
            ZStack{
                Path { path in
                    path.move(to: CGPoint(x: 200, y: 178))  
                    path.addQuadCurve(
                        to: CGPoint(x: 230, y: 205),        
                        control: CGPoint(x: 220, y: 185)    
                    )
                }
                .stroke(Color.black, lineWidth: 3) //右眉毛
                Path { path in
                    path.move(to: CGPoint(x: 160, y: 175))  
                    path.addQuadCurve(
                        to: CGPoint(x: 135, y: 190),        
                        control: CGPoint(x: 140, y: 180)    
                    )
                }
                .stroke(Color.black, lineWidth: 3) //右眉毛
                
                Path { path in
                    path.move(to: CGPoint(x: 305, y: 370)) 
                    path.addQuadCurve(
                        to: CGPoint(x: 282, y: 415), 
                        control: CGPoint(x: 300, y: 415)
                    )
                }
                .stroke(Color.black, lineWidth: 3)
                //右下手
                Path { path in
                    path.move(to: CGPoint(x: 332, y: 440))
                    path.addQuadCurve(
                        to: CGPoint(x: 292, y: 464), 
                        control: CGPoint(x: 320, y: 460)
                    )
                }
                .stroke(Color.black, lineWidth: 3)
                Path { path in
                    for i in 0..<5 { // 右五隻手指
                        let startY = 435 + i * 10
                        let endY   = 445 + i * 10
                        let x      = 250 + i * 0  // 每隻手指往下排一點點
                        let control = CGPoint(x: x - 10, y: (startY + endY)/2 ) // 控制點
                        
                        path.move(to: CGPoint(x: x, y:startY ))
                        path.addQuadCurve(to: CGPoint(x: x, y: endY),
                                          control: control)
                        
                        
                    }
                }
                .stroke(Color.black, lineWidth: 3)
                .rotationEffect(.degrees(-15))
                
                //左手
                Path { path in
                    path.move(to: CGPoint(x: 150, y: 400))  
                    path.addQuadCurve(
                        to: CGPoint(x: 246, y: 448), 
                        control: CGPoint(x: 180, y: 450) 
                    )
                }
                .stroke(Color.black, lineWidth: 3)
                Path { path in
                    path.move(to: CGPoint(x: 150, y: 460))
                    path.addQuadCurve(
                        to: CGPoint(x:255, y: 497),
                        control: CGPoint(x: 180, y: 500)
                    )
                }
                .stroke(Color.black, lineWidth: 3)//左下
                Path { path in
                    for i in 0..<5 { // 五隻手指
                        let startY = 100 + i * 10
                        let endY   = 110 + i * 10
                        let x      = 165 + i * 0  // 每隻手指往下排一點點
                        let control = CGPoint(x: x - 10, y: (startY + endY)/2 ) 
            
                        path.move(to: CGPoint(x: x, y:startY ))
                        path.addQuadCurve(to: CGPoint(x: x, y: endY),
                                          control: control)
                        
                        
                    }
                }
                .stroke(Color.black, lineWidth: 3)
                .rotationEffect(.degrees(-190))
                
                Path { path in
                    path.move(to: CGPoint(x: 120, y: 560))
                    path.addQuadCurve(
                        to: CGPoint(x: 90, y: 670), 
                        control: CGPoint(x: 10, y: 600) 
                    )
                }
                .stroke(Color.white, lineWidth:10)//tail
                
                
                
                
            }
            
        }
        
        
    }
}

