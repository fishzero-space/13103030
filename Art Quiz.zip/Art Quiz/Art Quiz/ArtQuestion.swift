//
//  ArtQuestion.swift
//  Art Quiz
//
//  Created by YU LING CHEN on 2025/11/17.
//
import SwiftUI
import Combine

struct ArtQuestion: Identifiable {
    let id = UUID()
    let imageName: String
    let question: String
    let options: [String]
    let correctAnswerIndex: Int
}

let artQuestions = [
    ArtQuestion(
        imageName: "napoleon_crossing_alps",
        question: "《拿破崙鎮靜駕馭烈馬橫越阿爾卑斯山》中，雅克-路易·大衛刻意理想化拿破崙的原因是？",
        options: [
            "宣傳拿破崙作為革命英雄的形象",
            "記錄真實的戰役場景",
            "諷刺拿破崙的權力慾望",
            "模仿古希臘神話題材"
        ],
        correctAnswerIndex: 0
    ),
    ArtQuestion(
        imageName: "liberty_leading_people",
        question: "《自由引導人民》描繪的是哪一場歷史事件？",
        options: ["法國大革命", "七月革命", "二月革命", "普法戰爭"],
        correctAnswerIndex: 1
    ),
    ArtQuestion(
        imageName: "gleaners",
        question: "米勒的《拾穗》被視為現實主義作品，主要因為它——",
        options: [
            "描繪工業城市景象",
            "以神話形式象徵豐收",
            "強調自然的詩意光影",
            "描繪農民勞動的真實與尊嚴"
        ],
        correctAnswerIndex: 3
    ),
    ArtQuestion(
        imageName: "moulin_de_la_galette",
        question: "《煎餅磨坊》中雷諾瓦的筆觸特點是？",
        options: [
            "柔和流動的色彩與光影氣氛",
            "嚴謹的透視與線條結構",
            "單色的象徵性筆觸",
            "抽象的幾何形構"
        ],
        correctAnswerIndex: 0
    ),
    ArtQuestion(
        imageName: "impression_sunrise",
        question: "莫內《日出·印象》中最能體現印象派特質的是？",
        options: [
            "宗教象徵主題",
            "瞬間光影與色彩變化的捕捉",
            "古典透視構圖",
            "以素描打底的明暗對比"
        ],
        correctAnswerIndex: 1
    ),
    ArtQuestion(
        imageName: "mona_lisa",
        question: "《蒙娜麗莎》中神秘微笑的效果\n主要來自於達文西使用了？",
        options: ["暈塗法（Sfumato）", "厚塗法（Impasto）", "點描法（Pointillism）", "平塗技法（Flat color）"],
        correctAnswerIndex: 0
    ),
    ArtQuestion(
        imageName: "raft_of_medusa",
        question: "《梅杜薩之筏》的主題來源於？",
        options: [
            "聖經洪水傳說",
            "希臘神話故事",
            "拿破崙遠征",
            "真實海難事件與政治醜聞"
        ],
        correctAnswerIndex: 3
    ),
    ArtQuestion(
        imageName: "weeping_woman",
        question: "畢卡索的《哭泣的女人》\n延伸自他哪一幅更具政治性的作品？",
        options: ["《亞維農的少女》", "《鏡前的女子》", "《格爾尼卡》", "《老吉他手》"],
        correctAnswerIndex: 2
    ),
    ArtQuestion(
        imageName: "sunflowers",
        question: "梵谷的《向日葵》\n系列最初創作的目的為何？",
        options: [
            "描繪家鄉的農田景色",
            "迎接高更到訪黃屋作為裝飾",
            "象徵信仰的重生",
            "個人喜好無特別理由"
        ],
        correctAnswerIndex: 1
    ),
    ArtQuestion(
        imageName: "the_kiss",
        question: "下列選項誰是《吻》的作者？",
        options: [
            "畢卡索","塞尚","克林姆","馬奈"
        ],
        correctAnswerIndex: 2
    ),
    ArtQuestion(
        imageName: "angelus",
        question: "《晚禱》中兩位農民低頭祈禱，象徵——?",
        options: [
            "對古典神話的懷舊",
            "生計受到剝削的平民",
            "宗教對貴族的約束",
            "人與自然的謙卑共存"
        ],
        correctAnswerIndex: 3
    ),
    ArtQuestion(
        imageName: "last_supper",
        question: "《最後的晚餐》中，\n達文西用透視法聚焦於哪個人物？",
        options: ["耶穌", "彼得", "猶大", "約翰"],
        correctAnswerIndex: 0
    ),
    ArtQuestion(
        imageName: "dance_class",
        question: "竇加《歌劇院的舞蹈教室》中主要探討的主題是？",
        options: [
            "畫家的兒時記憶",
            "當代社會的奢侈藝術",
            "都市生活的觀察與瞬間動態",
            "宗教與道德的衝突"
        ],
        correctAnswerIndex: 2
    ),
    ArtQuestion(
        imageName: "starry_night",
        question: "梵谷在《星夜》中表達的情感傾向最接近哪一類？",
        options: ["自然的客觀再現", "精神的焦慮與宇宙的孤寂", "對現代都市的批判", "宗教的救赦與秩序"],
        correctAnswerIndex: 1
    ),
    ArtQuestion(
        imageName: "birth_of_venus",
        question: "波提且利《維納斯的誕生》融合了哪兩種思想？",
        options: ["巴洛克與哥德風格", "現實主義與浪漫主義",        "印象派與象徵主義", "古典神話與基督教人文主義"],
        correctAnswerIndex: 3
    ),
    ArtQuestion(
        imageName: "girl_with_piano",
        question: "雷諾瓦的《彈鋼琴的少女》體現了他對什麼題材的偏愛？",
        options: ["享受音樂的藝術生活", "社會底層的勞動者", "家庭與日常生活的溫柔氛圍", "都市夜景"],
        correctAnswerIndex: 2
    ),
    ArtQuestion(
        imageName: "girl_with_pearl_earring",
        question: "維梅爾《戴珍珠耳環的少女》最著名的光線特色是？",
        options: [
            "象徵性的彩色反射光",
            "強烈的明暗對比",
            "舞台式聚光燈效果",
            "自然柔光下的清澈肌理與靜謐氛圍"
        ],
        correctAnswerIndex: 3
    ),
    ArtQuestion(
        imageName: "las_meninas",
        question: "委拉斯開茲《侍女》中，畫家將自己置入畫面目的為？",
        options: ["諷刺王室貴族的舊俗", "彰顯宗教權威", "探討觀看與被觀看的關係", "表現戰爭榮耀"],
        correctAnswerIndex: 2
    ),
    ArtQuestion(
        imageName: "creation_of_adam",
        question: "米開朗基羅的《創造亞當》創作收藏於何處？",
        options: ["巴黎羅浮宮", "西斯汀教堂", "烏菲茲美術館", "奧賽博物館"],
        correctAnswerIndex: 1
    ),
    ArtQuestion(
        imageName: "the_scream",
        question: "《吶喊》被視為哪一藝術運動的先聲？",
        options: ["表現主義", "印象派", "立體主義", "未來主義"],
        correctAnswerIndex: 0
    ),
    ArtQuestion(
        imageName: "sunday_on_la_grande_jatte",
        question: "秀拉《傑克島的星期天下午》使用了哪種光學原理？",
        options: ["暈塗技法", "透視縮放法", "色彩對比理論", "視覺混色理論"],
        correctAnswerIndex: 3
    ),
    ArtQuestion(
        imageName: "the_third_class_carriage",
        question: "杜米爾《三等車廂》最能代表哪個主題？",
        options: ["宗教儀式的莊嚴", "當時多數人民的生活風格", "工業化下的社會階層與勞動貧困", "戰後社會的傷痛與重建"],
        correctAnswerIndex: 2
    ),
    ArtQuestion(
        imageName: "birthday",
        question: "夏卡爾的《生日》中融入了的哪種風格？",
        options: ["野獸派的大膽與創新", "夢幻象徵與個人記憶的交融", "立體主義構圖", "社會寫實主義"],
        correctAnswerIndex: 1
    ),
    ArtQuestion(
        imageName: "persistence_of_memory",
        question: "達利《時光靜止》中融化的鐘錶象徵著？",
        options: ["機械文明的力量", "現代科技的精確性", "抽象失序的幻想", "時間的流動與潰解"],
        correctAnswerIndex: 3
    ),
    ArtQuestion(
        imageName: "arnolfini_wedding",
        question: "楊·范·艾克《阿諾菲尼的婚禮》最著名的細節是？",
        options: ["凸面鏡反射出畫外人物", "婚禮的象徵性裝飾", "背景牆上的簽名", "畫中主角微妙的神情"],
        correctAnswerIndex: 0
    ),
    ArtQuestion(
        imageName: "madame_pompadour",
        question: "布雪筆下的《龐波德夫人》展現了洛可可風格的什麼特質？",
        options: ["對奢華上流階級的諷喻", "貴族對宗教的敬虔", "華麗優雅與感官愉悅的生活品味", "絕對的對稱構圖"],
        correctAnswerIndex: 2
    ),
    ArtQuestion(
        imageName: "dancer_two",
        question: "馬蒂斯《舞者·二》屬於哪個藝術流派？",
        options: ["超現實主義", "野獸派", "立體主義", "象徵主義"],
        correctAnswerIndex: 1
    ),
    ArtQuestion(
        imageName: "anatomy_lesson",
        question: "林布蘭特《杜爾博士的解剖學課》中，\n光線的用途是？",
        options: [
            "純粹寫實的自然效果",
            "創造宗教神秘感",
            "象徵理性與知識的啟蒙",
            "模仿舞台燈光的聚焦效果"
        ],
        correctAnswerIndex: 2
    ),
    ArtQuestion(
        imageName: "ophelia",
        question: "米雷《奧菲莉亞》的靈感來自於哪部文學作品？",
        options: ["莎士比亞《哈姆雷特》", "但丁《神曲》", "歌德《浮士德》", "霍夫曼《胡桃鉗》"],
        correctAnswerIndex: 0
    ),
    ArtQuestion(
        imageName: "apples_oranges",
        question: "塞尚《蘋果和柳橙的靜物》\n被視為哪個藝術運動的先驅？",
        options: ["立體主義", "浪漫主義", "野獸派", "象徵主義"],
        correctAnswerIndex: 0
    ),
    ArtQuestion(
            imageName: "mucha_zodiac",
            question: "《黃道帶》中慕夏展現的新藝術（Art Nouveau）特色為何？",
            options: ["強烈幾何構成、黑白對比", "象徵女性形象的花草裝飾與曲線", "古典透視、均衡三角構圖", "厚塗與狂放筆觸"],
            correctAnswerIndex: 1
        ),
    ArtQuestion(
        imageName: "sleeping_venus",
        question: "《入睡的維納斯》被認為開啟了哪項後來在文藝復興與巴洛克中常見的傳統？",
        options: [   "宗教場景中的透視法精準化",
                     "風景畫與肖像畫的融合",
                     "世俗女性裸體以神話名義呈現",
                     "超現實象徵主義的象徵符號"],
        correctAnswerIndex: 2
    ),
    ArtQuestion(imageName: "madonna_child",
                question: "拉斐爾的《聖母與聖子》最能反映他哪項典型風格？",
                options: ["強烈明暗對比與戲劇性",
                "人體比例變形與動態追求",
                "和諧構圖、溫柔情感與理想化人物",
                "宗教象徵的繁複隱喻"],
                correctAnswerIndex: 3
    ),
    ArtQuestion(imageName: "composition_no1",
                question: "蒙得里安的《擬畫一號》中，他使用黑線與原色矩形的目的為何？",
                options: [
                    "表現戰爭的破碎與混亂",
                    "構成純粹秩序與普遍性的美學哲學",
                    "描繪都市景觀的抽象印象",
                    "探索隨機性與情緒筆觸"],
                correctAnswerIndex: 1
    ),
    ArtQuestion(imageName: "womanbird_night", question: "米羅的《夜裡的女人與鳥》使用大量符號化圖形，其創作方法最接近哪項超現實技法？",
                options: [
                    "自動性書寫（Automatism）",
                    "拼貼法（Collage）",
                    "達利的寫實變形法",
                    "象徵性寓言構圖"],
                correctAnswerIndex: 0
    ),
    ArtQuestion(imageName:"death_of_marat",
                question: "《馬拉之死》中，大衛刻意削弱血腥與細節，使其更接近何種畫風？",
                options:  [
                    "浪漫主義的激情呈現",
                    "洛可可式的柔美構圖",
                    "現代寫實主義的直接描繪",
                    "古典殉道者形象的理想化"],
                correctAnswerIndex: 3
    ),
    ArtQuestion(imageName: "tahitian_women_beach",
                question: "高更的《沙灘上的大溪地女人》展現了他旅居大溪地後常見的哪種特徵？",
                options:  [
                    "光線寫實與自然色調",
                    "厚重筆觸與激烈情緒",
                    "色塊平面化與原始性象徵",
                    "精準透視與古典比例"],
                correctAnswerIndex: 2
    ),
    ArtQuestion(imageName: "execution_lady_jane_grey",
                question: "《珍·葛蕾夫人的處刑》之所以震撼 19 世紀觀眾，是因為德拉羅什運用了什麼特質？",
                options:  [
                    "極度戲劇化的宗教象徵",
                    "細緻到如攝影般的歷史再現",
                    "完全抽象化的情感表達",
                    "空白背景與純色場域"],
                correctAnswerIndex: 1
    ),
    ArtQuestion(imageName: "lovers", question: "芙烈達·卡蘿的《畫家與他的情人》最常被解讀為什麼？",
                options:[
                    "政治寓言對殖民壓迫的反思",
                    "對自身創傷的怨懟",
                    "對夢境的超現實探索",
                    "以雙重身份隱喻破碎的婚姻與自我"],
                correctAnswerIndex: 3
    ),
    ArtQuestion(imageName: "the_dream", question: "畢卡索的《夢》屬於哪一個創作時期？",
                options: [
                    "藍色時期",
                    "玫瑰時期",
                    "立體派成熟期",
                    "與瑪莉·特瑞莎之戀的黃金情人時期"],
                correctAnswerIndex: 3
    ),
    ArtQuestion(imageName: "the_weeping_king", question: "《國王的悲哀》運用馬蒂斯晚期常見的哪種特質？",
                options: [
                    "線條即興化與象徵性簡化",
                    "古典比例回歸",
                    "立體派幾何拆解",
                    "宗教象徵與金箔技法"],
                correctAnswerIndex: 0
    ),
    ArtQuestion(imageName: "rape_of_sabine_women", question: "普桑的《洗劫色賓婦女》展現了他哪種典型的古典主義理念？",
                options: [
                    "情感即興的混亂戰鬥場景",
                    "光線主導空間的印象式構圖",
                    "安排人物群像的理想劇場式布局",
                    "強調個體心理描寫"],
                correctAnswerIndex: 2)
]
