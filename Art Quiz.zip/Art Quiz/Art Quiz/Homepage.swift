//
//  Homepage.swift
//  Art Quiz
//
//  Created by YU LING CHEN on 2025/11/17.
//

import SwiftUI

struct HomeView: View {
    @Binding var path: NavigationPath

    var body: some View {
        ZStack{
            Image("bg1")
                .scaledToFit()
                .ignoresSafeArea()
                .opacity(0.9)

            VStack(spacing: 20){
                Text("Masterpiece Quest")
                    .foregroundStyle(.white)
                    .font(.system(size: 25,weight: .bold,design: .serif))
                    .fontWeight(.medium)
                Text("藝術鑑賞家")
                    .font(.system(size: 50,weight: .bold,design: .serif))
                    .foregroundStyle(.white)
                    .shadow(radius: 10)

                Button("開始測驗") {
                    path.append("quiz")
                }
                .font(.title2)
                .fontWeight(.bold)
                .padding()
                .frame(width:150)
                .background(Color(red: 97/255, green: 37/255, blue: 30/255))
                .foregroundStyle(.background)
                .cornerRadius(30)
            }
        }
        .navigationDestination(for: String.self) { value in
            if value == "quiz" {
                QuizView(path: $path)
            }
        }
    }
}
