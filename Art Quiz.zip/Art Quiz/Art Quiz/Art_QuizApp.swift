//
//  Art_QuizApp.swift
//  Art Quiz
//
//  Created by YU LING CHEN on 2025/11/17.
//

import SwiftUI

@main
struct Art_QuizApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
