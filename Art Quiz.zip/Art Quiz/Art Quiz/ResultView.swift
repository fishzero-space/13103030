//
//  ResultView.swift
//  Art Quiz
//
//  Created by YU LING CHEN on 2025/11/19.
//

import SwiftUI

struct ResultView: View {
    @Environment(\.dismiss)  var dismiss
    @Binding var path: NavigationPath

    let score: Int
    let highScore: Int
    let rankmessage: String
    let restart: () -> Void

    var body: some View {
        ZStack{
            Image("bg3")
                .scaledToFit()
                .ignoresSafeArea()
                .opacity(0.8)
            Color.black
                .opacity(0.4)
            Rectangle()
                .frame(width: 600,height: 290)
                .foregroundStyle(.black)
                .opacity(0.6)
                .offset(y:-60)
          

            VStack(alignment: .center, spacing: 10){
                Text("Quiz Result")
                    .foregroundStyle(.white)
                    .font(.system(size: 20,weight: .bold,design: .serif))
                    .fontWeight(.medium)
                    .shadow(radius: 20)

                Text(" 評級結果 ")
                    .font(.system(size: 50,weight: .bold,design: .serif))
                    .foregroundStyle(.white)
                    .shadow(radius: 5)
                    .padding()

                Text("❖ 本回得分：\(score)")
                    .font(.headline)
                    .foregroundStyle(.white)
               

                Text("❖ 歷史高分：\(highScore)")
                    .font(.headline)
                    .foregroundStyle(.white)

                Text(rankmessage)
                    .font(.system(size: 22,weight: .bold,design: .serif))
                    .foregroundStyle(.white)
                    .padding(25)
                
                HStack{
                    
                    Button("重新開始"){
                        restart()
                    }
                    .fontWeight(.bold)
                    .padding()
                    .frame(width:100)
                    .background(Color(red: 97/255, green: 37/255, blue: 30/255))
                    .foregroundStyle(.background)
                    .cornerRadius(30)
                    
                    
                    Button("回到首頁"){
                        path.removeLast(path.count)
                    }
                    .fontWeight(.bold)
                    .padding()
                    .frame(width:100)
                    .background(Color(red: 97/255, green: 37/255, blue: 30/255))
                    .foregroundStyle(.background)
                    .cornerRadius(30)
                }
                .padding()
            }
        }
        .padding()
    }
}

