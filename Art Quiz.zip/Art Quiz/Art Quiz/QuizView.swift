//
//  QuizView.swift
//  Art Quiz
//
//  Created by YU LING CHEN on 2025/11/19.
//

import SwiftUI
import Combine

struct QuizView: View {
    @Environment(\.dismiss) private var dismiss
    @Binding var path: NavigationPath

    @State private var questions: [ArtQuestion] = Array(artQuestions.shuffled().prefix(10))
    @State private var currentQuestionIndex: Int = 0
    @State private var score: Int = 0
    @State private var correctStreak: Int = 0
    @State private var answerFeedback: String = ""
    @State private var showAnswerFeedback: Bool = false
    @State private var showResult: Bool = false
    @State private var highScore: Int = UserDefaults.standard.integer(forKey: "HighScore")
    @State private var showfinalAnswerAlert: Bool = false
    @State private var goToResult = false

    var currentQuestion: ArtQuestion {
        questions[currentQuestionIndex]
    }

    var rankMessage: String {
        if score >= 140 { return "恭喜你成為一級鑑賞師！" }
        if score >= 110 { return "恭喜你成為二級鑑賞師！" }
        if score >= 80  { return "恭喜你成為三級鑑賞師！" }
        return "要成為美術鑑賞師，你還差得遠呢！"
    }

    func checkAnswer(_ index: Int) {
        if index == currentQuestion.correctAnswerIndex {
            score += 10
            correctStreak += 1
            answerFeedback = "答對 ✓"
            if correctStreak == 3 {
                answerFeedback += " \n連對三題 + 30 分！"
                score += 30
                correctStreak = 0
            }
        } else {
            score -= 10
            correctStreak = 0
            answerFeedback = "錯誤 ✗ \n正確答案：\(currentQuestion.options[currentQuestion.correctAnswerIndex])"
        }
        if currentQuestionIndex + 1 == questions.count {
            showfinalAnswerAlert = true
        } else {
            showAnswerFeedback = true
        }
    }

    func nextQuestion() {
        showAnswerFeedback = false
        if currentQuestionIndex + 1 < questions.count {
            currentQuestionIndex += 1
        } else {
            endGame()
        }
    }

    func endGame() {
        showResult = true
        if score > highScore {
            highScore = score
            UserDefaults.standard.set(score, forKey: "HighScore")
        }
    }

    func restart() {
        questions = Array(artQuestions.shuffled().prefix(10))
        currentQuestionIndex = 0
        score = 0
        correctStreak = 0
        answerFeedback = ""
        showAnswerFeedback = false
        showResult = false
        showfinalAnswerAlert = false
        goToResult = false
    }

    var body: some View {
        ZStack {
            Color.clear
                .navigationDestination(isPresented: $goToResult) {
                    ResultView(
                        path: $path,
                        score: score,
                        highScore: highScore,
                        rankmessage: rankMessage,
                        restart: {
                            restart()
                            goToResult = false
                        }
                    )
                }

            Image("bg2")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .opacity(0.6)

            VStack(spacing: 10) {
                HStack {
                    Text("Q \(currentQuestionIndex + 1) / \(questions.count) ")
                        .font(.system(size: 18,weight: .bold,design: .serif))
                        .foregroundStyle(.white)
                        .frame(width: 100,height: 30)
                        .background(.black.opacity(0.4))
                        .clipShape(.rect(cornerRadius: 20))
                        .font(.headline).bold()
                        .padding()
                    
                    Text("Score：\(score)")
                        .font(.system(size: 18,weight: .bold,design: .serif))
                        .foregroundStyle(.white)
                        .frame(width: 130,height: 30)
                        .background(.black.opacity(0.4))
                        .clipShape(.rect(cornerRadius: 20))
                        .padding()
                }

                Image(currentQuestion.imageName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 280, height: 280)
                    .shadow(radius: 20)

                Text(currentQuestion.question)
                    .font(.system(size: 20, weight: .bold))
                    .multilineTextAlignment(.center)
                    .padding()

                ForEach(0..<currentQuestion.options.count, id: \.self) { i in
                    Button {
                        checkAnswer(i)
                    } label: {
                        Text(currentQuestion.options[i])
                            .foregroundColor(.white)
                            .padding()
                            .frame(width: 300)
                            .background(Color(red: 82/255, green: 48/255, blue: 35/255))
                            .cornerRadius(15)
                    }
                    .disabled(showAnswerFeedback)
                }
            }
            .padding()
            .alert("解答", isPresented: $showAnswerFeedback) {
                Button("下一題") { nextQuestion() }
            } message: {
                Text(answerFeedback)
            }
            .alert("本題作答結果", isPresented: $showfinalAnswerAlert) {
                Button("重新開始") {
                    restart()
                }
                Button("查看結果") {
                    goToResult = true
                }
            } message: {
                Text(answerFeedback)
            }
        }
        
        .navigationDestination(isPresented: $showResult) {
            ResultView(
                path: $path,
                score: score,
                highScore: highScore,
                rankmessage: rankMessage,
                restart: {
                    restart()
                    showResult = false
                }
            )
        }
    }
}

