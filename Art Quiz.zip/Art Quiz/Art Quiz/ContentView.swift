//
//  ContentView.swift
//  Art Quiz
//
//  Created by YU LING CHEN on 2025/11/17.
//

import SwiftUI

struct ContentView: View {
    @State private var path = NavigationPath()

    var body: some View {
        NavigationStack(path: $path) {
            HomeView(path: $path)
        }
    }
}

#Preview {
    ContentView()
}
