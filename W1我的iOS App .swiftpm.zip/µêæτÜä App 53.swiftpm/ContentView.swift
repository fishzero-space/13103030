import SwiftUI
import AVFoundation

struct ContentView: View {
    @State private var showGame = false
    @State private var isFriendMode = false
    
    var body: some View {
        ZStack {
            // 首頁背景圖
            Image("cover") // 請把封面圖命名為 cover
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            
            if showGame {
                GameView(showGame: $showGame, isFriendMode: isFriendMode)
            } else {
                VStack(spacing: 40) {
                    Text("Air Hockey")
                        .font(.system(size: 56, weight: .bold,design: .rounded))
                        .foregroundColor(.black)
                        .shadow(radius: 5)
                    
                    Text("選擇遊戲模式")
                        .foregroundColor(.black.opacity(0.9))
                        .font(.subheadline)
                   
                        Button(" Play with AI  ") {
                        isFriendMode = false
                        showGame = true
                    }
                    .font(.title2) .bold()
                    .frame(minWidth: 180, minHeight: 35)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .shadow(radius: 5)
                    
                    Button("Play with Friend") {
                        isFriendMode = true
                        showGame = true
                    }
                    .font(.title2).bold()
                    .frame(minWidth: 180, minHeight: 35)
                    .padding()
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .shadow(radius: 5)
                  
                    Text("NTU iOS APP")
                        .foregroundColor(.white.opacity(0.85))
                        .font(.footnote)
                        .padding(.bottom)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .background(
                    LinearGradient(
                        gradient: Gradient(colors: [.white, .blue.opacity(0.2)]),
                        startPoint: .top, endPoint: .bottom
                    )
                )
            }
        }
    }
}

struct GameView: View {
    @Binding var showGame: Bool
    var isFriendMode: Bool
    
    @State private var playerPos = CGSize(width: 0, height: 250)
    @State private var aiPos = CGSize(width: 0, height: -250)
    @State private var puckPos = CGSize.zero
    @State private var puckVel = CGSize.zero
    
    @State private var scorePlayer = 0
    @State private var scoreAI = 0
    @State private var showResult = false
    @State private var resultText = ""
    
    @State private var countdown = 3
    @State private var showCountdown = true
    
    @State private var flashGoalTop = false
    @State private var flashGoalBottom = false
    
    let fieldWidth: CGFloat = 320
    let fieldHeight: CGFloat = 500
    
    var body: some View {
        ZStack {
            // 球場背景
            RoundedRectangle(cornerRadius: 20)
                .fill(Color.white)
                .frame(width: fieldWidth, height: fieldHeight)
                .shadow(radius: 50)
                .overlay(
                    ZStack {
                        // 中圈
                        Circle().stroke(Color.blue, lineWidth: 3)
                            .frame(width: 180, height: 180)
                        Circle().stroke(Color.red, lineWidth: 2)
                            .frame(width: 50, height: 50)
                        // 中線
                        Rectangle().fill(Color.red)
                            .frame(width: fieldWidth, height: 3)
                        
                        VStack {
                            Rectangle()
                                .fill(flashGoalTop ? Color.yellow : Color.yellow.opacity(0.5))
                                .frame(width: 120, height: 20)
                            Spacer()
                            Rectangle()
                                .fill(flashGoalBottom ? Color.yellow : Color.yellow.opacity(0.5))
                                .frame(width: 120, height: 20)
                        }
                    }
                )
            
            // 分數顯示
            HStack {
                Circle().fill(Color.red).frame(width: 40, height: 40)
                    .overlay(Text("\(scorePlayer)").foregroundColor(.white).bold())
                Spacer()
                Circle().fill(Color.blue).frame(width: 40, height: 40)
                    .overlay(Text("\(scoreAI)").foregroundColor(.white).bold())
            }
            .padding(.horizontal, -15)
            .position(x: fieldWidth/2, y: 250)
            
            // 玩家球槌（下方）
            Circle().fill(Color.red)
                .frame(width: 50, height: 50)
                .offset(playerPos)
                .shadow(radius: 5)
                .gesture(
                    DragGesture().onChanged { value in
                        let newX = max(-fieldWidth/2+30, min(value.translation.width, fieldWidth/2-30))
                        let newY = max(0, min(value.translation.height+250, fieldHeight/2-30))
                        playerPos = CGSize(width: newX, height: newY)
                    }
                )
            
            // 對手球槌（AI 或 玩家2）
            Circle().fill(Color.blue)
                .frame(width: 50, height: 50)
                .offset(aiPos)
                .shadow(radius: 5)
                .gesture(
                    isFriendMode ?
                    DragGesture().onChanged { value in
                        let newX = max(-fieldWidth/2+30, min(value.translation.width, fieldWidth/2-30))
                        let newY = min(0, max(value.translation.height-250, -fieldHeight/2+30))
                        aiPos = CGSize(width: newX, height: newY)
                    }
                    : nil
                )
            
            // 冰球
            Circle().fill(Color.black)
                .frame(width: 20, height: 20)
                .shadow(radius: 5)
                .offset(puckPos)
            
            // 倒數動畫
            if showCountdown {
                Text(countdown > 0 ? "\(countdown)" : "START!")
                    .font(.system(size: 40, weight: .bold))
                    .foregroundColor(.yellow)
                    .background(Color.black.opacity(0.6))
                    .cornerRadius(10)
            }
        }
        .frame(width: fieldWidth, height: fieldHeight)
        .onAppear {
            startCountdown()
            Timer.scheduledTimer(withTimeInterval: 0.02, repeats: true) { _ in
                if !showCountdown && !showResult {
                    movePuck()
                    if !isFriendMode { moveAI() }
                }
            }
        }
        .overlay(
            ZStack {
                if showResult {
                    // 半透明黑色底圖，蓋住球桌
                    Color.black.opacity(0.8)
                        .ignoresSafeArea()
                        .cornerRadius(10)
                
                    VStack(spacing: 20) {
                        Text(resultText)
                            .font(.largeTitle).bold()
                            .frame(minWidth: 180, minHeight: 35)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.red)
                            .cornerRadius(100)
                        
                        Button("  Play Again    ") {
                            resetGame()
                        }
                        .font(.title2).bold()
                        .frame(minWidth: 180, minHeight: 35)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(30)
                        
                        Button("Back to Home") {
                            showGame = false
                        }
                        .font(.title2).bold()
                        .frame(minWidth: 180, minHeight: 35)
                        .padding()
                        .background(Color.white)
                        .cornerRadius(30)
                    }
                }
            }
        )
    }
    // MARK: - 遊戲邏輯
    
    func startCountdown() {
        countdown = 3
        showCountdown = true
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
            if countdown > 0 {
                countdown -= 1
            } else {
                showCountdown = false
                puckVel = CGSize(width: 4, height: 4)
                timer.invalidate()
            }
        }
    }
    
    func movePuck() {
        puckPos.width += puckVel.width
        puckPos.height += puckVel.height
        
        // 邊界反彈
        if abs(puckPos.width) > fieldWidth/2 - 10 {
            puckVel.width *= -1
            playSound()
        }
        if abs(puckPos.height) > fieldHeight/2 - 10 {
            puckVel.height *= -1
            playSound()
        }
        
        // 球槌碰撞
        if distance(puckPos, playerPos) < 40 {
            puckVel.height = -abs(puckVel.height) - 1
            playSound()
        }
        if distance(puckPos, aiPos) < 40 {
            puckVel.height = abs(puckVel.height) + 1
            playSound()
        }
        
        // 進球判定
        if puckPos.height < -fieldHeight/2 {
            scorePlayer += 1
            goalScored(top: true)
        }
        if puckPos.height > fieldHeight/2 {
            scoreAI += 1
            goalScored(top: false)
        }
        
        // 遊戲結束
        if scorePlayer == 5 {
            resultText = "WIN!"
            showResult = true
        } else if scoreAI == 5 {
            resultText = "LOSE..."
            showResult = true
        }
    }
    
    func moveAI() {
        // AI 簡單邏輯
        if puckPos.height < 0 {
            if puckPos.width > aiPos.width {
                aiPos.width += 2
            } else {
                aiPos.width -= 2
            }
        }
    }
    
    func goalScored(top: Bool) {
        puckPos = .zero
        puckVel = .zero
        if top {
            flashGoalTopEffect()
        } else {
            flashGoalBottomEffect()
        }
        startCountdown()
    }
    
    func flashGoalTopEffect() {
        var flashes = 0
        Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true) { timer in
            flashGoalTop.toggle()
            flashes += 1
            if flashes >= 6 {
                timer.invalidate()
                flashGoalTop = false
            }
        }
    }
    
    func flashGoalBottomEffect() {
        var flashes = 0
        Timer.scheduledTimer(withTimeInterval: 0.3, repeats: true) { timer in
            flashGoalBottom.toggle()
            flashes += 1
            if flashes >= 6 {
                timer.invalidate()
                flashGoalBottom = false
            }
        }
    }
    
    func resetGame() {
        scorePlayer = 0
        scoreAI = 0
        puckPos = .zero
        puckVel = .zero
        showResult = false
        startCountdown()
    }
    
    func distance(_ a: CGSize, _ b: CGSize) -> CGFloat {
        let dx = a.width - b.width
        let dy = a.height - b.height
        return sqrt(dx*dx + dy*dy)
    }
    
    func playSound() {
        AudioServicesPlaySystemSound(1104)
    }
}

#Preview {
    ContentView()
}
